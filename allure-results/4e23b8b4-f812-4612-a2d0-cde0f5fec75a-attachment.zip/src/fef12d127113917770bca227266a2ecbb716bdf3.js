import {test, expect} from "@playwright/test"
import {customTest} from "../Utils/testBase"
test.skip("swagdemo", async({page})=>{
    await page.goto("https://www.saucedemo.com/");
    
    const username = await page.locator("#user-name")
    await username.fill("standard_user");
    const password = await page.locator("#password")
    await password.fill("secret_sauce");
    const loginbtn = await page.getByRole("button", {name: "Login"})
    await loginbtn.click()

    const prdtTitle = page.locator(".inventory_item_name ")
    const titles = await prdtTitle.allTextContents()  //for getting multiple text contents
    console.log(titles)

    const myprdct = 'Sauce Labs Backpack'
    const count = await prdtTitle.count()
    console.log(count)
    const inven_descr = await page.locator(".inventory_item_description")
    for(let i=0;i<count;i++)
        {
        if(await inven_descr.locator(".inventory_item_name ").nth(i).textContent()===myprdct){
            console.log(await inven_descr.locator(".inventory_item_name ").nth(i).textContent())
            const addcart_btn = await page.getByText("Add to cart").nth(i).click()
            //const cartbttn = await page.locator(".shopping_cart_badge").click();
            
        }
        }
      const cartbttn = await page.locator(".shopping_cart_link").click()
      const cartitem = await page.locator(".cart_item_label .inventory_item_name").textContent()
      console.log(cartitem);
      await expect(cartitem).toContain(myprdct);
      const checkoutbttn = await page.locator("#checkout").click();
      const firstname = await page.locator("#first-name").fill("megha");
      const lastname = await page.locator("#last-name").fill("saji");
      const zip = await page.locator("#postal-code").fill("1234");
      const continuebttn = await page.locator("#continue").click();
      const finishbttn = await page.locator("#finish").click();
      const thnksmsg = await page.locator(".checkout_complete_container .complete-header").textContent()
      console.log(thnksmsg);
      await expect(thnksmsg).toContain("Thank you");
    await page.pause();
})

    customTest("swagdemo with fixture", async({page, loginFixture})=>{
    await page.goto("https://www.saucedemo.com/");
    
    const username = await page.locator("#user-name")
    await username.fill(loginFixture.username);
    const password = await page.locator("#password")
    await password.fill(loginFixture.password);
    const loginbtn = await page.getByRole("button", {name: "Login"})
    await loginbtn.click()

     const prdtTitle = page.locator(".inventory_item_name ")
    const titles = await prdtTitle.allTextContents()  //for getting multiple text contents
    console.log(titles)

    const myprdct = 'Sauce Labs Backpack'
   // const count = await prdtTitle.count()
   const count= await loginFixture.myprdct.count
    console.log(count)
    const inven_descr = await page.locator(".inventory_item_description")
    for(let i=0;i<count;i++)
        {
        if(await inven_descr.locator(".inventory_item_name ").nth(i).textContent()===myprdct){
            console.log(await inven_descr.locator(".inventory_item_name ").nth(i).textContent())
            const addcart_btn = await page.getByText("Add to cart").nth(i).click()
            //const cartbttn = await page.locator(".shopping_cart_badge").click();
            
        }
        }
      //const cartbttn = await page.locator(".shopping_cart_link").click()
      const cartbttn = await loginFixture.myprdct.cartbttn.click()
      //const cartitem = await page.locator(".cart_item_label .inventory_item_name").textContent()
        const cartitem = await loginFixture.myprdct.cartitem.textContent()
      console.log(cartitem);
      await expect(cartitem).toContain(myprdct);
      const checkoutbttn = await page.locator("#checkout").click();
      const firstname = await page.locator("#first-name").fill("megha");
      const lastname = await page.locator("#last-name").fill("saji");
      const zip = await page.locator("#postal-code").fill("1234");
      const continuebttn = await page.locator("#continue").click();
      const finishbttn = await page.locator("#finish").click();
      const thnksmsg = await page.locator(".checkout_complete_container .complete-header").textContent()
      console.log(thnksmsg);
      await expect(thnksmsg).toContain("Thank you");
    await page.pause();

    })
